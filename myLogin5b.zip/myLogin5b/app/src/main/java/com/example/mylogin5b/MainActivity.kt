package com.example.mylogin5b

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mylogin5b.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Creamos la conexion a la BD
        val dbHelper = DBHelperUsuario(this)
        //Click al boton Login
        binding.btnLogin.setOnClickListener {
            //Tomamos las valores de las cajas de texto
            val loginInput = binding.txtUsuario.getText().toString()
            val passInput = binding.txtPassword.getText().toString()
            //Abrimos la BD para solo lectura
            val db = dbHelper.readableDatabase
            //Creamos los argumentos para ejecutar la consulta
            val selectionArgs = arrayOf(loginInput, passInput)
            //Ceamos variable cursor para ejecutar la consulta
            val cursor = db.rawQuery(   "SELECT * FROM usuarios WHWRW userLogin = ? AND userPass = ?", selectionArgs)
            //Verificamos si se encontro ocurrencia en la consulta, moviendo el cursor al inicio
            if (cursor.moveToFirst()) {
                Toast.makeText(this, "El usuario es correcto :-)", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText( this,   "Usuario invalido :-(", Toast.LENGTH_SHORT).show()
            }
            //cerramos el cursor
            cursor.close()
            //cerramos la BD
            db.close()
        }



    }
}