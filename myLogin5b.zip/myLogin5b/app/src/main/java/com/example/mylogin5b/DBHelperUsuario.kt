package com.example.mylogin5b

import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelperUsuario (context: Context) : SQLiteOpenHelper (context, DB_name, null, DB_version) {
    override fun onCreate(db: SQLiteDatabase?) {
        db.execSQL(sqlCreate)

    }

    override fun onUpgrade( db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $nomTabla")
        onCreate(db)
    }

    override fun onDowgrade (db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }


    companion object{
        private val DB_version = 1
        private val DB_name = "dbServicios"
        private val nomTable = "usuario"
        private val keyId = "id"
        private val usrLogin = "userPass"
        private val usrPass = "userEmail"
        private val usrEmail = "userEmail"
        private val usrNombre = "userNombre"
    }

    //Variable para crear nuestra tabla
    val sqlCreate: String = "CREATE TABLE $nomTable ($keyId INTEGER PRIMARY KEY, $usrLogin TEXT, $usrPass TEXT, $usrEmail TEXT, $usrNombre TEXT)"
    {
}